﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace JWTAuthentication_TokenBarer.Controllers
{
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [ApiController]
    [Route("[controller]")]

    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "IRISH COFFEE", "BRANDY ALEXANDER", "OLD CUBAN", "BAMBOO", "SIDECAR", "VODKA MARTINI", "RAMOS GIN FIZZ", "CAIPIRINHA", "GIN GIN MULE", "VESPER"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            var ml = new Random();
            return Enumerable.Range(1, 10).Select(index => new WeatherForecast
            {
                Price = rng.Next(100, 500),
                Drinks = Summaries[rng.Next(Summaries.Length)],
                Measure = ml.Next(100, 300)
            })
            .ToArray();
        }

        private int Measure(object ml)
        {
            throw new NotImplementedException();
        }
    }
}
