using System;

namespace JWTAuthentication_TokenBarer
{
    public class WeatherForecast
    {
        public int Price { get;  set; }
        public string Drinks { get;  set; }
        public int Measure { get;  set; }
    }
}
